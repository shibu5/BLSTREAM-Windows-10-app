﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;

namespace Pat_1.Model
{
    public class lista_klasa
    {
        public string Nazwa { get; set; }
        public BitmapImage Image { get; set; }
        public int id { get; set; }
        public int wysokosc1 { get; set; }
        public int szerokosc1 { get; set; }
        public int szerokosc2 { get; set; }
    }
}
